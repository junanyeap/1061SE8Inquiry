## Backend of ecology management system

### Installation

```
    請點右邊綠色 Clone or Download 並下載為zip使用
    前端開發請下載後另外git至前端repo (避免多組共用程式碼污染)
```

```
開發基於 https://github.com/TMineCola/bookPrj
```

### 前端

- 主要進行 View 的建置, 並利用GET、POST Method針對Controller進行操作或直接呼叫Function中的函式獲得資料

*** 如果發現有錯誤, 麻煩告知一下 ***

### 後端

- 主要進行 Control邏輯 及 Module與DB溝通, 提供前端所需要的資料